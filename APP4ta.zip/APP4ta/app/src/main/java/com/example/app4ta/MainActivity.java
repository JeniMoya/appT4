package com.example.app4ta;


import android.app.DatePickerDialog;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;




public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.nav_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.Inicio:
                Toast.makeText(this, "¡Inicio!", Toast.LENGTH_SHORT).show();

            return true;
            default:
            case R.id.perfil:
                Toast.makeText(this, "¡Perfil!", Toast.LENGTH_SHORT).show();

            return true;
            case R.id.configuracion:
                Toast.makeText(this, "¡configuración!", Toast.LENGTH_SHORT).show();

            return true;

        }return super.onOptionsItemSelected(item);
    }




}
